* Para correr el programa: python main.py
Posibles flags:
	* -f [Nombre de archivo]: Para el archivo que contiene los resultados.
	* -s [0 o 1]: Para el selector (1 es RouletteWheel, 0 es Tournament).
	* -e [0 o 1]: Para indicar si se desea elitismo (1) o no (0).
	* -c [Float]: Para indicar la tasa de crossover.
	* -m [Float]: Para indicar la tasa de mutacion.